import pymysql

con=pymysql.connect(host='bcwhjiwtbxzzkwyovwdm-mysql.services.clever-cloud.com',user='ulc4etvmoz4obvgi',password='ZoyjYoH5DVOoUuJeTF6Z',database='bcwhjiwtbxzzkwyovwdm')
curs=con.cursor()

comp=input("Enter the Comapny: ")

curs.execute("select * from mobiles where company='%s' order by price" %comp)
data=curs.fetchall()
print(data)
con.close()
