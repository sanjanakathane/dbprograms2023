import pymysql

con=pymysql.connect(host='bcwhjiwtbxzzkwyovwdm-mysql.services.clever-cloud.com',user='ulc4etvmoz4obvgi',password='ZoyjYoH5DVOoUuJeTF6Z',database='bcwhjiwtbxzzkwyovwdm')
curs=con.cursor()

try:
    pid=input("Enter the prodid: ")
    curs.execute("Select * from mobiles where prodid='%s' "%pid)
    data=curs.fetchone()

    if data:
        print(data)
        dele=input("Do you want to delete (yes/no): ")

        if dele=='yes':
            curs.execute("delete from mobiles where prodid='%s'"%pid)
            con.commit()
            print("Mobile data deleted......")
        else:
            print("Not want to delete the data.......")

    else:
        print("Mobile is not found......")
 
except Exception as err:
    print('error',err)

con.close()