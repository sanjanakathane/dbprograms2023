import pymysql
try:
    con=pymysql.connect(host='bcwhjiwtbxzzkwyovwdm-mysql.services.clever-cloud.com',user='ulc4etvmoz4obvgi',password='ZoyjYoH5DVOoUuJeTF6Z',database='bcwhjiwtbxzzkwyovwdm')
    curs=con.cursor()

    pid=input("Enter the prodid: ")
    mdnm=input("Enter the model name: ")
    comp=input("Enter the Company: ")
    contype=input("Enter the connectivity: ")
    rm=input("Enter the ram: ")
    ro=input("Enter the rom: ")
    col=input("Enter the color: ")
    scr=input("Enter the screen: ")
    bry=input("Enter the battery: ")
    pcr=input("Enter the processor: ")
    pri=int(input("Enter the price: "))
    rat=float(input("Enter the Rating: "))

    curs.execute("insert into mobiles values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%d,%.2f)" %(pid,mdnm,comp,contype,rm,ro,col,scr,bry,pcr,pri,rat))
    con.commit()
    print('Record added Successfully..............')
    con.close()

except Exception as err:
    print('Error - ',err)





