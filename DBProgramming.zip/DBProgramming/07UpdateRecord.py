import pymysql

con=pymysql.connect(host='bcwhjiwtbxzzkwyovwdm-mysql.services.clever-cloud.com',user='ulc4etvmoz4obvgi',password='ZoyjYoH5DVOoUuJeTF6Z',database='bcwhjiwtbxzzkwyovwdm')
curs=con.cursor()

mdnm=input("Enter the Modle Name: ")
pro=input("Enter the Purpose: ")

curs.execute("update mobiles set purpose='%s' where modelnm='%s'" %(pro,mdnm))
con.commit()
print("Data added succesfully........")
con.close()