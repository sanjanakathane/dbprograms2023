import pymysql

con=pymysql.connect(host='bcwhjiwtbxzzkwyovwdm-mysql.services.clever-cloud.com',user='ulc4etvmoz4obvgi',password='ZoyjYoH5DVOoUuJeTF6Z',database='bcwhjiwtbxzzkwyovwdm')
curs=con.cursor()

pid=input("Enter the product id: ")

curs.execute("select * from mobiles where prodid='%s'" %pid)
data=curs.fetchone()

if data:
    pr=int(input("Enter the price: "))
    curs.execute("update mobiles set price=%d where prodid='%s'" %(pr,pid))
    con.commit()
    print("Price updated Successfully......")
else:
    print("Mobile not found....")

con.close()
