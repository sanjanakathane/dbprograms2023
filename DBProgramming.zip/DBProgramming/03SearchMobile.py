import pymysql

con=pymysql.connect(host='bcwhjiwtbxzzkwyovwdm-mysql.services.clever-cloud.com',user='ulc4etvmoz4obvgi',password='ZoyjYoH5DVOoUuJeTF6Z',database='bcwhjiwtbxzzkwyovwdm')
curs=con.cursor()

modnm=input('Enter modelname : ')
curs.execute("select * from mobiles where  modelnm='%s'" %modnm)
data=curs.fetchone()

if data:
    print(data)
else:
    print("Mobile not found..........")

con.close()